<footer class="footer-wrapper">
  <div class="site-container">
    <div class="pull-right">
      Password management system
    </div>
  </div>
</footer>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="HandheldFriendly" content="false"/>
  <meta name="viewport" content="user-scalable=yes, width=device-width"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <script type="text/javascript" src="theme/js/lib/jquery.min.js"></script>
  <script type="text/javascript" src="theme/js/lib/jquery.formstyler.min.js"></script>
  <script type="text/javascript" src="theme/js/lib/scroll.js"></script>
  <script type="text/javascript" src="theme/js/js.js"></script>

  <title>TestJob</title>
  <link href="theme/css/styles.css" rel="stylesheet" type="text/css">
</head>
<body class="front page">
<header id="site-header" class="site-header">
  <div class="site-container">
    <div class="logo">
      <a href="#"><img src="theme/images/icons/logo.png" alt=""></a>
    </div>

    <div class="btn-wrap">
      <a href="index.php" class="btn">Search</a>
      <a href="addpage.php" class="btn">Add</a>
    </div>
  </div>
</header>
